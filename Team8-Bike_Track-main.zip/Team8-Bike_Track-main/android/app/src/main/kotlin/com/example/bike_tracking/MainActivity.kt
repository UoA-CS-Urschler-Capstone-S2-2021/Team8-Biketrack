package com.example.bike_tracking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
