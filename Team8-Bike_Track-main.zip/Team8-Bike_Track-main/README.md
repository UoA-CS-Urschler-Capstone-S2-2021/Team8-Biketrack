# BikeTracks App Development


## Getting Started

The purpose of this project was to develop a mobile application that allows tracking of smarthphone sensor data. The information is stored in a simple database format based on timestamps. This project can be extended into various finalities, such as a pathway to machine learning of commutes used by people.

## Introduction 

An Android App that can track users’ GPS information, speed, accelerometer and then store those data as well as time and vehicle type into plain text files.
Report
https://docs.google.com/document/d/1qPsZDGJTwVv7BNdI6m5Avc8jguixa8To/edit?usp=sharing&ouid=116485613096975310137&rtpof=true&sd=true

## Technologies

Flutter SDK and Dart was used to build the App. Geolocator 7.6.0 was used to get the GPS information. This project only works with geolocator 7.6.0. Sensor_plus ^1.1.0 was used to get the accelerometer and gyroscope. Intl ^0.17.0 was used to show the accurate time. Build_runner ^2.1.2 was used to generate the files. Path_provider ^2.0.3 was used to set the path of the generated files. Json_seriablizable ^4.1.3 was used to convert the data into JSON format.

## Installation

Here is the link to the apk file: https://github.com/shaaen26/BikeTrackFinalVersion.git
This file can be installed on Android devices and this app is only functional on the devices with the Google framework.
The path of the stored data is: /Android/data/com.example.bike_tracking/files/data.txt

## Future work

Replace vehicle type choosing function with machine learning to distinguish the vehicle type by analyzing the data.
Add weather forecaster function to the app. This 
Add a user login function and data can be stored under different users
Add the Google Map API to the app so that the users can figure out their accurate locations.
Improve the UI to let users have a better user experience

## Project management

Here is the link to the network diagram: https://docs.google.com/document/d/1tkWZdzozo7493gRAdBKwBdSn8OrTVL-7TOqXAE7GuQQ/edit?usp=sharing
It is clear to show cirtical path, eatimate duration of each sub-task and total project duration.

## Acknowledgments

Thanks to Free Courses Online Official for providing tutorials to the new beginners using Flutter.
https://www.youtube.com/channel/UCuRevelSM8Z_nyK4xmkg1eA

Speacial Thanks to Asam, Martin, and Elisa for assistance during the duration of the project.


## 
**deets:**
Last updated: Fri 6:20 pm (20th Oct 2021)
