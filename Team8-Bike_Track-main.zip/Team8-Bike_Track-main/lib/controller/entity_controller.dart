import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:bike_tracking/model/trip_list.dart';
import 'global.dart';

class EntityController {

  // Unused class

}
